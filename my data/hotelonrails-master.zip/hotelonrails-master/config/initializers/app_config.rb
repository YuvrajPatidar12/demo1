APP_CONFIG = YAML.load_file("#{Rails.root}/config/app_config.yml")

