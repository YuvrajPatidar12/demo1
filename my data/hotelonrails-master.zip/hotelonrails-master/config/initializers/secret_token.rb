# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Hsahara::Application.config.secret_token = 'c11b9995f5727299024a6b94aaf028e16aeaf2d3eeab545f38854392131ae093399616550edc434d4900b980867544b7504b32288fa7758d717dec00dacc334b'
