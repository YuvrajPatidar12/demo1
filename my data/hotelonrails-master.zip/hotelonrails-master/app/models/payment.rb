class Payment < ActiveRecord::Base
  belongs_to :checkin
end
