class RoomType < ActiveRecord::Base
end
