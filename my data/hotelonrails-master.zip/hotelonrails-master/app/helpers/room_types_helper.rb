module RoomTypesHelper
end
