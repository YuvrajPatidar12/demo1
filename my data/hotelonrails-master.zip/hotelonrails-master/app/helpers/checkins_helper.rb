module CheckinsHelper
end
