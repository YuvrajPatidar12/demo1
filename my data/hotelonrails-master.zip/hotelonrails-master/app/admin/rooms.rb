ActiveAdmin.register Room do
  
end
