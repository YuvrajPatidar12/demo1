ActiveAdmin.register Company do
  
end
