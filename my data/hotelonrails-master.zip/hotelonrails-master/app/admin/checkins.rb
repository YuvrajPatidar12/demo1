ActiveAdmin.register Checkin do
  
end
