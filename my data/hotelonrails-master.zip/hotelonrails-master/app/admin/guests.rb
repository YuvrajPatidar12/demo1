ActiveAdmin.register Guest do
  
end
