ActiveAdmin.register Service do
  
end
