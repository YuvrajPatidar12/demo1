ActiveAdmin.register RoomType do
  
end
