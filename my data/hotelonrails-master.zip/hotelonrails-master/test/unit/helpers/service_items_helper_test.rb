require 'test_helper'

class ServiceItemsHelperTest < ActionView::TestCase
end
