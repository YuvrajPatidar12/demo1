require 'test_helper'

class RoomTypesHelperTest < ActionView::TestCase
end
