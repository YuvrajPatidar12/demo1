require 'test_helper'

class CheckinsHelperTest < ActionView::TestCase
end
