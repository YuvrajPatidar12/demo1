FactoryGirl.define do
  factory :room do 
  	price 7000
  	rno "A01"
  	room_type 0
  	created_at Time.now
  	updated_at	 Time.now
	end
end