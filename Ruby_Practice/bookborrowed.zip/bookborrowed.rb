
# TEST_Case  = 1
borrowed_books = [
  {
    "book"=> "Ruby",
    "borrower"=> "abc",
    "date"=> "10-May-2023",
  },
  {
    "book"=> "rails",
    "borrower"=> "abc1",
    "date"=> "16-March-2021",
  },
  {
    "book"=> "ROR",
    "borrower"=> "abc2",
    "date"=> "21-April-2020",
  }
]
user_name = "abc"


# Test_case = 2
# borrowed_books = [
#   {
#     "book"=> "Python",
#     "borrower"=> "abc",
#     "date"=> "10-May-2021",
#   },
#   {
#     "book"=> "java",
#     "borrower"=> "abc1",
#     "date"=> "16-March-2021",
#   },
#   {
#     "book"=> "c++",
#     "borrower"=> "abc2",
#     "date"=> "21-April-2020",
#   }
# ]
# user_name = "abc1"



# Test Case 3


# borrowed_books = [
#   {
#     "book"=> "c",
#     "borrower"=> "abc",
#     "date"=> "10-May-2021",
#   },
#   {
#     "book"=> "c++",
#     "borrower"=> "abc1",
#     "date"=> "16-March-2021",
#   },
#   {
#     "book"=> "JS",
#     "borrower"=> "abc2",
#     "date"=> "21-April-2020",
#   }
# ]
# user_name = "cba"


def test(borrowed_books, username)
  case username
  when username = "#{borrowed_books[0]["borrower"]}"
    puts "#{borrowed_books[0]["borrower"]} borrowed '#{borrowed_books[0]["book"]}' on #{borrowed_books[0]["date"]}"
  when username = borrowed_books[1]["borrower"]
    puts "#{borrowed_books[1]["borrower"]} borrowed '#{borrowed_books[1]["book"]}' on #{borrowed_books[1]["date"]}"
  when username = borrowed_books[2]["borrower"]
    puts "#{borrowed_books[2]["borrower"]} borrowed '#{borrowed_books[2]["book"]}' on #{borrowed_books[2]["date"]}"
  else
    puts "Sorry, you are not borrowed any book"
  end
end

puts test(borrowed_books, user_name)